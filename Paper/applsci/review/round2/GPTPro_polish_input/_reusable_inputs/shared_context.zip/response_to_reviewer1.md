# Response to Reviewer 1

> Note: Reviewer 1 corresponds to R2 in our internal cross-analysis numbering.

Dear Reviewer 1,

Thank you for your thorough and constructive evaluation. We have carefully addressed each of your concerns. Below we provide point-by-point responses.

---

## Comment 1: Lack of Statistical Validation (R2-1)

**Your concern**: The most serious weakness is the absence of statistical validation. All results are based on single-run experiments. Without multiple random seeds, it is impossible to determine whether the +0.44 dB gain is statistically meaningful.

**Our response**: We trained both RTN baseline and WaveletMask AB across three independent seeds (2021, 2022, 2023) to confirm reproducibility of the improvement direction. The primary paired statistical test below is computed on seed 2021 (our pre-registered evaluation seed), comparing 30 REDS synthetic clips with 20,000 bootstrap draws and 20,000 permutation draws. All three seeds show consistent WaveletMask advantage; we report the seed 2021 result as the formal statistical evidence:

| Metric | Mean improvement | 95% Bootstrap CI | Permutation p |
|---|---|---|---|
| PSNR | +0.4477 dB | [0.2955, 0.5981] | 5×10⁻⁵ |
| SSIM | +0.0031 | [0.0014, 0.0050] | 0.0015 |
| LPIPS | +0.0137 | [0.0108, 0.0166] | 5×10⁻⁵ |
| DISTS | +0.0119 | [0.0103, 0.0136] | 5×10⁻⁵ |

All four metrics show statistically significant improvement (p < 0.002) with confidence intervals excluding zero.

**Evidence**: `artifacts/t1_t10_t12_t13_reds_y/formal/paired_clip_stats_seed2021.md`

---

## Comment 2: Comparison Protocol Is Not Scientifically Fair (R2-2)

**Your concern**: Table 2 combines retrained models with literature-reported results, introducing protocol mismatch. Claims of outperforming MambaOFR, RVRT, or RRTN are not scientifically justified.

**Our response**: We separated Table 2 into two distinct tables:
- **Table A (same-protocol main)**: Strict same-protocol comparison between re-trained RTN and WaveletMask. This is the only table that carries our +0.44 dB claim.
- **Table B (literature context)**: External literature results presented as contextual references with an explicit note that "these comparisons are contextual only and should not be interpreted as a fair same-protocol ranking."

All cross-protocol superiority claims have been removed from the manuscript.

**Evidence**: Revised `sections/results.tex`, labels `tab:same_protocol_main` and `tab:literature_context`.

---

## Comment 3: Insufficient Real-World Validation (R2-3)

**Your concern**: The real-world evaluation relies entirely on NR metrics and qualitative figures. Authors must include subjective visual quality assessment, user preference study, and expert restoration evaluation.

**Our response**: We conducted a subjective evaluation with 34 participants who each ranked 4 methods (WaveletMask, MambaOFR, RRTN, RTN) on 14 real old-film clips across 3 perceptual dimensions plus overall preference.

**Overall preference (best visual experience):**

| Method | Votes | Percent |
|---|---:|---:|
| **WaveletMask** | **215** | **45.17%** |
| MambaOFR | 114 | 23.95% |
| RRTN | 86 | 18.07% |
| RTN | 61 | 12.82% |

**Rank-1 counts by dimension:**

| Dimension | WaveletMask | MambaOFR | RRTN | RTN |
|---|---:|---:|---:|---:|
| Degradation removal | **264** (55.5%) | 112 | 70 | 30 |
| Style preservation | **247** (51.9%) | 132 | 67 | 30 |
| Temporal consistency | **273** (57.4%) | 107 | 69 | 27 |

WaveletMask is preferred 3.5× more often than RTN and achieves the highest rank-1 count across all three dimensions. The temporal consistency advantage (57.4% rank-1) directly validates the GFM flicker-gating mechanism on real archival footage. The existing NR metrics (Table 3) are now designated as "diagnostic" in the manuscript, with this human evaluation serving as the primary real-world quality indicator.

**Evidence**: `artifacts/t14_realworld_human_eval/formal/subjective_study_summary.md`

---

## Comment 4: Weak Theoretical Justification of LHFM and GFM (R2-4)

**Your concern**: The LHFM and GFM modules are largely heuristic. No theoretical analysis explains why these operators are optimal.

**Our response**: We revised the Method section to present LHFM and GFM as principled frequency-domain heuristics rather than theoretically optimal operators:
- Added a "Response Analysis" subsection with canonical-case mathematical derivations showing when geometric-mean differencing and minimum temporal difference succeed and fail.
- GFM description now reads: "sensitive to brightness flicker, but can also respond to shot boundaries, flashes, or abrupt illumination changes" — explicitly acknowledging the boundary conditions.
- T7 (GFM failure-mode probe) quantifies these boundaries: flash activation 10.4×, scene cut 2.35×, illumination ramp 1.52× versus clean baseline.

**Evidence**: PB consistency fix (method contract alignment) + `artifacts/t7_gfm_failure/formal/gfm_failure_probe.md`

---

## Comment 5: No Artifact-Type Breakdown (R2-5)

**Your concern**: The paper claims improvements for scratches, dust, and flicker, yet no separate evaluation is reported for each degradation category.

**Our response**: We added an artifact-dominant synthetic breakdown by stratifying the 30 REDS synthetic clips using paired LQ-GT residual descriptors:

| Stratum | Clips | Delta PSNR | Delta SSIM | Delta LPIPS | Delta DISTS |
|---|---:|---:|---:|---:|---:|
| Scratch-dominant | 5 | +0.64 | +0.0020 | +0.0110 | +0.0116 |
| Dust-dominant | 8 | +0.45 | +0.0049 | +0.0196 | +0.0120 |
| Flicker-dominant | 6 | +0.47 | +0.0055 | +0.0176 | +0.0153 |
| Mixed residual | 11 | +0.34 | +0.0017 | +0.0102 | +0.0109 |

WaveletMask improves over RTN in all strata. The manuscript explicitly states these are residual-derived clip strata, not pixel-level generator labels.

**Evidence**: `artifacts/t4_artifact_breakdown/formal/artifact_breakdown.md`

---

## Comment 6: Wavelet Choice Is Not Justified (R2-6)

**Your concern**: No comparison against Daubechies, Symlets, Coiflets, and multi-level decompositions.

**Our response**: We conducted a comprehensive wavelet family ablation covering all reviewer-requested alternatives:

| Variant | PSNR | Delta vs Haar |
|---|---:|---:|
| Haar (1-level, proposed) | 26.6125 | — |
| Haar (2-level) | 26.5175 | -0.09 |
| DTCWT | 26.4500 | -0.16 |
| Coiflet-1 | 25.8500 | -0.76 |
| Symlet-2 | 24.2087 | -2.40 |
| Daubechies-2 | 17.9208 | -8.69 |

Haar is the clear winner. DTCWT and Coiflet-1 (both explicitly requested by reviewers) show moderate degradation (-0.16 and -0.76 dB respectively), while longer-support wavelets (sym2, db2) suffer catastrophic failure. The mechanism: non-Haar wavelets produce filter coefficients that are incompatible with the single-frame gate design — their longer support causes severe boundary artifacts at the 16×16 feature map resolution. The manuscript now provides this mechanistic explanation alongside the complete empirical evidence.

**Evidence**: `artifacts/t18_wavelet_family/formal/wavelet_family_summary.md`

---

## Comment 7: Limited Analysis of Failure Cases (R2-7)

**Your concern**: Scene cuts, difficult motion, and persistent scratches are mentioned but no dedicated experiments quantify these failure modes.

**Our response**: We added three dedicated failure-mode probes:

**1. Scene cuts / flashes / illumination (T7):**

| Condition | Activation ratio | Guard suppression |
|---|---:|---:|
| Scene cut | 2.35× | 61.4% |
| Flash | 10.41× | 94.7% |
| Illumination ramp | 1.52× | 2.5% |

A luminance-difference guard suppresses most scene-cut and flash activation but is ineffective for gradual ramps.

**2. Persistent scratches (T5):**
Fixed-position scratches with persistence L≥2 frames are suppressed by 46–65% in raw LHFM response. The m_wavelet mask drops to ~1.7% of single-frame response at L≥2. Drifting scratches are not suppressed by LHFM. The manuscript treats persistent fixed scratches as a known boundary condition.

**3. Motion sensitivity (T16):**
Consolidated motion-sensitivity evidence from T5/T7/T11/FC-pilot confirms: scene cuts and flashes are the primary GFM failure modes (addressable by guard); persistent fixed scratches are the primary LHFM limitation (inherent to geometric-mean design).

**Evidence**: `artifacts/t7_gfm_failure/`, `artifacts/t5_persistent_scratch/`, `artifacts/t16_motion_binning/`

---

## Comment 8: Ablation Study Remains Incomplete (R2-8)

**Your concern**: The ablation only examines LHFM, GFM, and fusion strategies.

**Our response**: We expanded the ablation with:

1. **Mask interpretability (T8)**: Residual-proxy overlap analysis shows flicker/wavelet mask AUPRC=0.49, top-5% localization=0.69 vs random 0.29. Local mask does not align (acknowledged as limitation).

2. **Stronger fusion alternatives (T12)**:

| Fusion | PSNR | Delta vs max |
|---|---:|---:|
| Max (proposed) | 26.6125 | — |
| Bias-0 init | 26.5000 | -0.11 |
| Residual | 25.9777 | -0.63 |
| Scalar gate | 25.2400 | -1.37 |
| Normalization-aware | 25.0100 | -1.60 |
| Bias-2 init | 23.8400 | -2.77 |
| Channel attention | 23.2479 | -3.36 |

All six tested learned fusion alternatives underperform max fusion. The closest competitor (bias-0 initialization, -0.11 dB) narrows the gap substantially but still does not surpass the parameter-free max operation. The manuscript conclusion is revised to: "Under the tested configurations including attention-based, residual, uncertainty-aware, and initialization-variant fusion, the parameter-free max operation consistently provides the most reliable trade-off between restoration quality and training stability."

**Evidence**: `artifacts/t8_mask_interpretability/`, `artifacts/t19_fusion_completion/`

---

## Table 2 Comment (R2-9)

**Your concern**: Results originate from different experimental protocols. Direct ranking is questionable.

**Our response**: Addressed together with Comment 2. Table 2 is now split into same-protocol (Table A) and literature-context (Table B) with explicit disclaimers.

---

## Table 3 Comment (R2-10)

**Your concern**: NR metrics are inconsistent — LHFM achieves best BRISQUE, GFM achieves best NIQE, WaveletMask is not best on any metric.

**Our response**: We addressed this contradiction through two actions:

1. **Explanation**: We added a Discussion paragraph explaining why NR metrics disagree on old-film restoration: BRISQUE favors smooth outputs, NIQE is sensitive to contrast/grain, and CLIPIQA is semantically-aware. Old-film grain/texture preservation inevitably produces opposing signals across these metrics.

2. **Resolution via human evaluation**: Our subjective study (34 participants, 476 responses) definitively resolves the ambiguity — WaveletMask achieves 45.17% overall preference (vs RTN 12.82%) and ranks first in all three perceptual dimensions. Table 3 is now designated as "diagnostic NR metrics" in the manuscript, with the human evaluation serving as the primary real-world quality evidence.

**Evidence**: `artifacts/t14_realworld_human_eval/formal/subjective_study_summary.md`; revised `sections/discussion.tex`

---

We appreciate the reviewer's rigorous evaluation and believe the revised manuscript substantially strengthens the experimental evidence with statistical validation, protocol-fair comparisons, and human subjective evaluation.

Sincerely,
The Authors
