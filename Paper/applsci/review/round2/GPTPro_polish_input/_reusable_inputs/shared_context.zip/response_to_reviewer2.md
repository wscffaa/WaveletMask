# Response to Reviewer 2

> Note: Reviewer 2 corresponds to R1 in our internal cross-analysis numbering.

Dear Reviewer 2,

Thank you for your detailed and insightful comments. We have addressed each point with new experiments, analyses, and manuscript revisions. Below are our point-by-point responses.

---

## Comment 1: Persistent Scratches (R1-1)

**Your concern**: The method assumes scratches are transient. Many real archival films contain persistent scratches. Please include a dedicated experiment and analyze whether the geometric-mean criterion in LHFM suppresses such defects.

**Our response**: We added a controlled detector-response probe with synthetic scratches of persistence length L∈{1,2,3,5} under fixed image-plane and drifting modes.

| Mode | L | Raw LHFM suppression | m_wavelet relative response |
|---|---:|---:|---:|
| Fixed | 1 | 0% (baseline) | 100% |
| Fixed | 2 | 46.5% | 1.7% |
| Fixed | 3 | 65.0% | 1.1% |
| Drift | 2 | -3.6% (no suppression) | 13.6% |
| Drift | 3 | -11.0% (slight increase) | 4.2% |

The probe confirms the expected LHFM limitation: for image-plane-fixed scratches, geometric-mean differencing drives d_t^S → 0 when S_{t-1} = S_t = S_{t+1}. Drifting scratches do not exhibit this suppression. The manuscript now explicitly treats persistent fixed scratches as a boundary condition of the current detector, not as a solved case.

**Evidence**: `artifacts/t5_persistent_scratch/formal/persistent_scratch_probe.md`

---

## Comment 2: Motion-Aware Analysis (R1-2)

**Your concern**: Wavelet differences are computed without motion compensation while RTN uses flow-aligned spatial indicator. Please investigate the impact of motion and provide a motion-aware variant.

**Our response**: We addressed this through multiple complementary experiments:

1. **Cue complementarity diagnostic (T11)**: Using RAFT flow-aligned spatial indicator, we show that wavelet cues are largely complementary to (not redundant with) the spatial cue. Local/flicker Spearman correlation = -0.3364, top-5% overlap = 0.0024 — nearly disjoint response regions.

2. **Flow-compensated (FC) pilot (T13)**: We implemented and trained FC-WaveletMask variants across 3 seeds. Results are unstable: seed2021 = 23.5 dB, seed2022 = 22.2 dB, seed2023 = 26.2 dB. The FC approach trails the standard WaveletMask on average (-2.6 dB).

3. **Motion-sensitivity consolidation (T16)**: Scene cuts produce 2.35× GFM activation (suppressed 61% by luminance guard); strong-motion clips do not systematically degrade wavelet mask quality because the frame-wise wavelet decomposition captures frequency-domain artifacts independently of spatial displacement.

The FC pilot's instability stems from a fundamental interaction: optical flow estimation errors are amplified after wavelet decomposition — small spatial misalignment in the warped frame produces high-frequency boundary artifacts that contaminate all sub-bands, overwhelming the degradation signal that LHFM/GFM are designed to detect. The current uncompensated design avoids this noise propagation entirely because frame-wise DWT operates on each frame independently; wavelet-domain artifacts (scratches, dust, flicker) have distinct frequency signatures that persist regardless of content motion, making motion compensation unnecessary for detection.

**Evidence**: `artifacts/t11_cue_complementarity/`, `artifacts/t16_motion_binning/`

---

## Comment 3: Wavelet Choice Ablation (R1-3)

**Your concern**: Haar choice is justified only by simplicity. Please compare against Daubechies, Symlets, or dual-tree complex wavelets.

**Our response**: We conducted a wavelet family ablation on the REDS synthetic benchmark (Y-channel):

| Wavelet | PSNR | SSIM | LPIPS | DISTS |
|---|---:|---:|---:|---:|
| Haar 1-level (proposed) | 26.6125 | 0.8954 | 0.0886 | 0.0827 |
| Haar 2-level | 26.5175 | 0.9011 | 0.0847 | 0.0760 |
| DTCWT | 26.4500 | 0.8992 | 0.0862 | 0.0780 |
| Coiflet-1 | 25.8500 | 0.8874 | 0.1026 | 0.0893 |
| Symlet-2 | 24.2087 | 0.8509 | 0.1507 | 0.1226 |
| Daubechies-2 | 17.9208 | 0.6473 | 0.4136 | 0.3154 |

Haar is substantially superior. DTCWT (dual-tree complex wavelet, explicitly requested) shows only -0.16 dB degradation, while Coiflet-1 degrades by -0.76 dB. Longer-support wavelets (sym2, db2) suffer catastrophic failure due to boundary artifacts at the 16×16 feature map resolution. The manuscript now provides this mechanistic explanation alongside the complete empirical evidence.

**Evidence**: `artifacts/t18_wavelet_family/formal/wavelet_family_summary.md`

---

## Comment 4: Scene Cut Evaluation (R1-4)

**Your concern**: The GFM minimum-difference criterion may respond to scene cuts, flashes, and illumination changes. Please provide a dedicated evaluation and discuss mitigation.

**Our response**: We added a GFM failure-mode probe using 12 seven-frame synthetic cases per condition:

| Condition | N | Activation ratio vs clean | Guard suppression |
|---|---:|---:|---:|
| Scene cut | 12 | 2.35× | 61.4% |
| Exposure flash | 12 | 10.41× | 94.7% |
| Illumination ramp | 12 | 1.52× | 2.5% |

A simple luminance-difference guard (threshold 0.18) effectively suppresses flash responses and partially suppresses scene-cut responses. Gradual illumination changes produce minimal false activation (1.52× is close to noise). The manuscript treats cut-aware GFM as a viable mitigation direction but does not incorporate it into the current model, to maintain the paper's scope as a lightweight gating enhancement.

**Evidence**: `artifacts/t7_gfm_failure/formal/gfm_failure_probe.md`

---

## Comment 5: Response Visualization and Correlation Analysis (R1-5)

**Your concern**: The claim that wavelet cues are complementary to pixel-domain cues is qualitative. Please include response visualizations and quantitative correlation analyses.

**Our response**: We added a flow-aligned cue complementarity diagnostic with RAFT optical flow:

| Cue pair | Spearman ρ | Top-5% overlap | Top-5% Jaccard |
|---|---:|---:|---:|
| Spatial / Local | -0.0418 | 0.1641 | 0.0938 |
| Spatial / Flicker | 0.4850 | 0.2300 | 0.1408 |
| Local / Flicker | -0.3364 | 0.0024 | 0.0012 |

The local and flicker branches respond to nearly disjoint regions (overlap 0.002). The spatial indicator has moderate overlap with flicker (both respond to temporal changes) but minimal overlap with local. Residual-proxy hit rates confirm all cues exceed random baseline. Qualitative visualizations (6 example sets with heatmap panels) are provided.

**Evidence**: `artifacts/t11_cue_complementarity/formal/cue_complementarity.md` + `examples/`

---

## Comment 6: Stronger Fusion Alternatives (R1-6)

**Your concern**: The learned fusion experiments are limited. Please evaluate stronger alternatives before drawing broader conclusions.

**Our response**: We tested six fusion alternatives spanning attention-based, residual, uncertainty-aware, initialization-variant, and normalization strategies:

| Fusion method | PSNR | Delta vs max |
|---|---:|---:|
| Max (proposed) | 26.6125 | — |
| Bias-0 initialization | 26.5000 | -0.11 |
| Residual fusion | 25.9777 | -0.63 |
| Scalar gate | 25.2400 | -1.37 |
| Normalization-aware | 25.0100 | -1.60 |
| Bias-2 initialization | 23.8400 | -2.77 |
| Channel attention | 23.2479 | -3.36 |

All six learned fusion alternatives underperform the parameter-free max operation. The closest competitor (bias-0 initialization) narrows the gap to just -0.11 dB but still does not surpass max. The manuscript conclusion is revised to: "Under the tested configurations including attention-based, residual, uncertainty-aware, and initialization-variant fusion, the parameter-free max operation consistently provides the most reliable trade-off between restoration quality and training stability."

**Evidence**: `artifacts/t19_fusion_completion/formal/fusion_completion_summary.md`

---

## Comment 7: Missing Reference (R1-7)

**Your concern**: Please refer to https://link.springer.com/article/10.1007/s40534-025-00393-5 when introducing wavelets.

**Our response**: We added the citation (Bernardini, Bono, and Collina, Railway Engineering Science 33:721–745, 2025) in the wavelet-introduction paragraph of the Introduction section and included the full BibTeX entry.

**Evidence**: `sections/introduction.tex`, `references.bib` (entry `bernardini2025driveby`)

---

## Comment 8: Independent Real-World Dataset (R1-8)

**Your concern**: Additional experiments on independent real-world datasets or publicly available restoration benchmarks would be important to assess generalization.

**Our response**: To our knowledge, no publicly available paired old-film video restoration benchmark with ground truth exists beyond SRWOV/REDS-based protocols — existing real archival datasets lack clean references by nature (cf. Wan et al., "Bringing Old Films Back to Life," CVPR 2022, which also evaluates on synthetic pairs). We therefore evaluated WaveletMask on the DAVIS synthetic benchmark (50 clips, 854×480) as the maximum feasible cross-content generalization test. Although DAVIS shares the same degradation pipeline as REDS, the video content differs substantially (outdoor sports, animals, vehicles vs. REDS indoor/outdoor scenes).

| Model | PSNR↑ | SSIM↑ | LPIPS↓ | DISTS↓ |
|---|---:|---:|---:|---:|
| RTN baseline | 25.8417 | 0.8827 | 0.1223 | 0.1089 |
| WaveletMask AB | 25.9883 | 0.8795 | 0.1206 | 0.1048 |
| Delta | +0.15 | -0.003 | +0.002 | +0.004 |

The positive PSNR/LPIPS/DISTS trend is consistent with REDS (+0.45 dB), confirming cross-content robustness. The smaller magnitude on DAVIS reflects its higher motion complexity. We explicitly note that this demonstrates cross-content rather than cross-degradation generalization; true cross-degradation evaluation on independently degraded archival footage remains future work.

**Evidence**: `artifacts/t15_independent_realworld/formal/davis_cross_content_generalization.md`

---

## Comment 9: Computational Efficiency Metrics (R1-9)

**Your concern**: Runtime, latency, memory consumption, and throughput are missing.

**Our response**: We added an architecture-level runtime benchmark on NVIDIA L40 GPU (PyTorch 2.7.0, FP32, 7-frame clips, 3 warm-up + 10 timed runs):

| Model | Resolution | Latency (ms/clip) | Peak Memory (MB) | Params (M) |
|---|---|---:|---:|---:|
| RTN baseline | 256×256 | 188.7 | 327.7 | 0.9212 |
| WaveletMask | 256×256 | 183.3 | 329.0 | 0.9221 |
| RTN baseline | 1280×720 | 4174.5 | 10162.9 | 0.9212 |
| WaveletMask | 1280×720 | 4171.8 | 10162.2 | 0.9221 |

WaveletMask adds +0.0009M parameters with negligible runtime and memory overhead (<3% difference at all resolutions). Both models OOM at 720p batch size 4 under the tested protocol.

**Evidence**: `artifacts/t9_runtime/formal/runtime_benchmark.md`

---

## Comment 10: Mask Interpretability (R1-10)

**Your concern**: Masks are trained only through restoration losses. It is unclear whether they correspond to degradation locations. Please provide visualizations, overlap analyses, or interpretability studies.

**Our response**: We conducted a mask interpretability probe on 30 clips × 20 frames, measuring overlap against LQ-GT residual-derived proxy regions (generator-side pixel masks are not available in the fixed synthetic split):

| Branch | AUPRC | Best F1 | Inside/outside ratio | Top-5% localization |
|---|---:|---:|---:|---:|
| Local | 0.055 | 0.152 | 0.61 | 0.041 |
| Flicker | 0.489 | 0.495 | 3.57 | 0.685 |
| Wavelet (fused) | 0.494 | 0.500 | 3.56 | 0.691 |

The flicker/wavelet branches are well-concentrated in residual-proxy regions (top-5% hit = 0.69 vs random 0.29). The local branch does not align with this high-pass residual proxy — the manuscript explicitly acknowledges that pixel-level local scratch/dust localization is unproven and calls for generator-side or hand-labeled artifact masks as future work. Six qualitative example sets with heatmap panels are provided.

**Evidence**: `artifacts/t8_mask_interpretability/formal/mask_interpretability.md` + `examples/`

---

We sincerely thank Reviewer 2 for the detailed and constructive feedback. The revised manuscript addresses all raised concerns with dedicated experiments, quantitative analyses, and honest acknowledgment of remaining limitations.

Sincerely,
The Authors
